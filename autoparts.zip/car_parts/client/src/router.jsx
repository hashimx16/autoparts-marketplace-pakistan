import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Login from './pages/Login';
import Signup from './pages/Signup';
import SellerDashboard from './pages/SellerDashboard';
import BuyerDashboard from './pages/BuyerDashboard';
import ProductDetails from './pages/ProductDetails';
import Cart from './pages/Cart';
import Orders from './pages/Orders';
import Profile from './pages/Profile';
import { getUser } from './utils/auth';
import Layout from './components/Layout/Layout';

const PrivateRoute = ({ children, role }) => {
  const user = getUser();
  if (!user) return <Navigate to="/login" />;
  if (role && user.role !== role) return <Navigate to="/" />;
  return children;
};

const Router = () => (
  <BrowserRouter>
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/signup" element={<Signup />} />
      <Route path="/seller" element={<Layout><PrivateRoute role="seller"><SellerDashboard /></PrivateRoute></Layout>} />
      <Route path="/buyer" element={<Layout><PrivateRoute role="buyer"><BuyerDashboard /></PrivateRoute></Layout>} />
      <Route path="/product/:id" element={<Layout><ProductDetails /></Layout>} />
      <Route path="/cart" element={<Layout><PrivateRoute role="buyer"><Cart /></PrivateRoute></Layout>} />
      <Route path="/orders" element={<Layout><PrivateRoute><Orders /></PrivateRoute></Layout>} />
      <Route path="/profile" element={<Layout><PrivateRoute><Profile /></PrivateRoute></Layout>} />
      <Route path="*" element={<Navigate to="/login" />} />
    </Routes>
  </BrowserRouter>
);

export default Router; 