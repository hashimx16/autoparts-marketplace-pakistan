import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import api from '../api';
import { Box, Typography, Button, Grid } from '@mui/material';

const ProductDetails = () => {
  const { id } = useParams();
  const [product, setProduct] = useState(null);

  useEffect(() => {
    api.get(`/products/${id}`).then(res => setProduct(res.data));
  }, [id]);

  const handleAddToCart = () => {
    let cart = JSON.parse(localStorage.getItem('cart') || '[]');
    const exists = cart.find(item => item.product._id === product._id);
    if (exists) exists.quantity += 1;
    else cart.push({ product, quantity: 1 });
    localStorage.setItem('cart', JSON.stringify(cart));
    alert('Added to cart!');
  };

  if (!product) return <Typography>Loading...</Typography>;

  return (
    <Box p={3}>
      <Typography variant="h4" mb={2}>{product.title}</Typography>
      <Grid container spacing={2}>
        <Grid item xs={12} md={6}>
          {product.images && product.images.map((img, i) => (
            <img key={i} src={`http://localhost:5000/uploads/${img}`} alt="" width={200} style={{ marginRight: 8 }} />
          ))}
        </Grid>
        <Grid item xs={12} md={6}>
          <Typography>{product.description}</Typography>
          <Typography color="primary" variant="h5">${product.price}</Typography>
          <Button variant="contained" color="primary" onClick={handleAddToCart} sx={{ mt: 2 }}>Add to Cart</Button>
        </Grid>
      </Grid>
    </Box>
  );
};

export default ProductDetails; 