import React, { useEffect, useState } from 'react';
import api from '../api';
import { Button, Box, Typography, Grid, Card, CardContent, CardActions, Dialog, DialogTitle, DialogContent, DialogActions, TextField, Alert, Paper } from '@mui/material';

const SellerDashboard = () => {
  const [products, setProducts] = useState([]);
  const [open, setOpen] = useState(false);
  const [editProduct, setEditProduct] = useState(null);
  const [form, setForm] = useState({ title: '', description: '', price: '', images: [], quantity: '' });
  const [error, setError] = useState('');

  const fetchProducts = async () => {
    const res = await api.get('/products/seller/listings');
    setProducts(res.data);
  };

  useEffect(() => { fetchProducts(); }, []);

  const handleOpen = (product = null) => {
    setEditProduct(product);
    setForm(product ? { ...product, price: product.price.toString(), images: [], quantity: product.quantity?.toString() || '' } : { title: '', description: '', price: '', images: [], quantity: '' });
    setOpen(true);
    setError('');
  };
  const handleClose = () => setOpen(false);

  const handleChange = e => {
    if (e.target.name === 'images') setForm({ ...form, images: e.target.files });
    else setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async e => {
    e.preventDefault();
    setError('');
    const data = new FormData();
    data.append('title', form.title);
    data.append('description', form.description);
    data.append('price', form.price);
    data.append('quantity', form.quantity);
    for (let i = 0; i < (form.images?.length || 0); i++) {
      data.append('images', form.images[i]);
    }
    try {
      if (editProduct) {
        await api.put(`/products/${editProduct._id}`, data);
      } else {
        await api.post('/products', data);
      }
      fetchProducts();
      handleClose();
    } catch (err) {
      setError(err.response?.data?.message || 'Error saving product');
    }
  };

  const handleDelete = async id => {
    if (!window.confirm('Delete this product?')) return;
    await api.delete(`/products/${id}`);
    fetchProducts();
  };

  return (
    <Box>
      <Box display="flex" alignItems="center" justifyContent="space-between" mb={3}>
        <Typography variant="h4">Seller Dashboard</Typography>
        <Button variant="contained" color="primary" onClick={() => handleOpen()}>Add Product</Button>
      </Box>
      <Grid container spacing={3}>
        {products.map(product => (
          <Grid item xs={12} sm={6} md={4} key={product._id}>
            <Paper elevation={2} sx={{ p: 2 }}>
              <Card elevation={0} sx={{ boxShadow: 'none' }}>
                <CardContent>
                  <Typography variant="h6">{product.title}</Typography>
                  <Typography color="text.secondary">{product.description}</Typography>
                  <Typography color="primary" fontWeight={700}>${product.price}</Typography>
                  <Typography color="text.secondary" fontSize={14}>In Stock: {product.quantity}</Typography>
                  {product.images && product.images.map((img, i) => (
                    <img key={i} src={`http://localhost:5000/uploads/${img}`} alt="" width={80} style={{ marginRight: 8, marginTop: 8, borderRadius: 4 }} />
                  ))}
                </CardContent>
                <CardActions>
                  <Button onClick={() => handleOpen(product)}>Edit</Button>
                  <Button color="error" onClick={() => handleDelete(product._id)}>Delete</Button>
                </CardActions>
              </Card>
            </Paper>
          </Grid>
        ))}
      </Grid>
      <Dialog open={open} onClose={handleClose}>
        <DialogTitle>{editProduct ? 'Edit Product' : 'Add Product'}</DialogTitle>
        <DialogContent>
          {error && <Alert severity="error">{error}</Alert>}
          <form id="product-form" onSubmit={handleSubmit}>
            <TextField label="Title" name="title" fullWidth margin="normal" value={form.title} onChange={handleChange} required />
            <TextField label="Description" name="description" fullWidth margin="normal" value={form.description} onChange={handleChange} required />
            <TextField label="Price" name="price" type="number" fullWidth margin="normal" value={form.price} onChange={handleChange} required />
            <TextField label="Quantity" name="quantity" type="number" fullWidth margin="normal" value={form.quantity} onChange={handleChange} required />
            <input type="file" name="images" multiple accept="image/*" onChange={handleChange} style={{ marginTop: 16 }} />
          </form>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleClose}>Cancel</Button>
          <Button type="submit" form="product-form" variant="contained">Save</Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default SellerDashboard; 