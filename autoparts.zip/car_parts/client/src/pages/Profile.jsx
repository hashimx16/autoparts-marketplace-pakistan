import React, { useEffect, useState } from 'react';
import api from '../api';
import { Box, Typography, TextField, Button, Alert, Paper } from '@mui/material';
import { getUser, setUser } from '../utils/auth';

const Profile = () => {
  const [profile, setProfile] = useState(null);
  const [name, setName] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('');
  const [success, setSuccess] = useState('');
  const [error, setError] = useState('');
  const user = getUser();

  useEffect(() => {
    api.get('/users/me').then(res => {
      setProfile(res.data);
      setName(res.data.name);
      setPaymentMethod(res.data.paymentMethod || '');
    });
  }, []);

  const handleUpdate = async e => {
    e.preventDefault();
    setError('');
    setSuccess('');
    try {
      const res = await api.put('/users/me', { name, paymentMethod });
      setProfile(res.data.user);
      setUser(res.data.user);
      setSuccess('Profile updated!');
    } catch (err) {
      setError('Update failed');
    }
  };

  if (!profile) return <Typography>Loading...</Typography>;

  return (
    <Box minHeight="70vh" display="flex" alignItems="center" justifyContent="center">
      <Paper elevation={3} sx={{ p: 4, width: 360 }}>
        <Typography variant="h5" mb={2} align="center">Profile</Typography>
        {error && <Alert severity="error">{error}</Alert>}
        {success && <Alert severity="success">{success}</Alert>}
        <form onSubmit={handleUpdate}>
          <TextField label="Name" fullWidth margin="normal" value={name} onChange={e => setName(e.target.value)} required />
          <TextField label="Email" fullWidth margin="normal" value={profile.email} disabled />
          <TextField label="Role" fullWidth margin="normal" value={profile.role} disabled />
          {user.role === 'seller' && (
            <TextField label="Payment Method" fullWidth margin="normal" value={paymentMethod} onChange={e => setPaymentMethod(e.target.value)} required />
          )}
          <Button type="submit" variant="contained" color="primary" fullWidth sx={{ mt: 2 }}>Update</Button>
        </form>
      </Paper>
    </Box>
  );
};

export default Profile; 