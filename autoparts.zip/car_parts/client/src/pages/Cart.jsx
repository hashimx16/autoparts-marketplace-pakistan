import React, { useState } from 'react';
import { Box, Typography, Button, Grid, TextField, Dialog, DialogTitle, DialogContent } from '@mui/material';
import api from '../api';
import { useNavigate } from 'react-router-dom';

const Cart = () => {
  const [cart, setCart] = useState(JSON.parse(localStorage.getItem('cart') || '[]'));
  const [open, setOpen] = useState(false);
  const navigate = useNavigate();

  const updateQuantity = (index, quantity) => {
    const newCart = [...cart];
    newCart[index].quantity = quantity;
    setCart(newCart);
    localStorage.setItem('cart', JSON.stringify(newCart));
  };

  const removeItem = (index) => {
    const newCart = cart.filter((_, i) => i !== index);
    setCart(newCart);
    localStorage.setItem('cart', JSON.stringify(newCart));
  };

  const handleCheckout = async () => {
    try {
      await api.post('/orders', {
        products: cart.map(item => ({ product: item.product._id, quantity: item.quantity })),
      });
      localStorage.removeItem('cart');
      setOpen(true);
    } catch (err) {
      alert('Checkout failed');
    }
  };

  const total = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

  return (
    <Box p={3}>
      <Typography variant="h4" mb={2}>Cart</Typography>
      {cart.length === 0 ? <Typography>Your cart is empty.</Typography> : (
        <>
          <Grid container spacing={2}>
            {cart.map((item, i) => (
              <Grid item xs={12} key={i}>
                <Box display="flex" alignItems="center" gap={2}>
                  <img src={`http://localhost:5000/uploads/${item.product.images[0]}`} alt="" width={60} />
                  <Typography flex={1}>{item.product.title}</Typography>
                  <TextField type="number" label="Qty" value={item.quantity} onChange={e => updateQuantity(i, Number(e.target.value))} sx={{ width: 80 }} />
                  <Typography>${item.product.price * item.quantity}</Typography>
                  <Button color="error" onClick={() => removeItem(i)}>Remove</Button>
                </Box>
              </Grid>
            ))}
          </Grid>
          <Typography variant="h6" mt={2}>Total: ${total}</Typography>
          <Button variant="contained" color="primary" onClick={handleCheckout} sx={{ mt: 2 }}>Checkout</Button>
        </>
      )}
      <Button sx={{ mt: 2 }} onClick={() => navigate('/buyer')}>Back to Products</Button>
      <Dialog open={open} onClose={() => setOpen(false)}>
        <DialogTitle>Payment Coming Soon</DialogTitle>
        <DialogContent>
          <Typography>Thank you for your order! Payment functionality is coming soon.</Typography>
          <Button variant="contained" color="primary" sx={{ mt: 2 }} onClick={() => { setOpen(false); navigate('/orders'); }}>Go to Orders</Button>
        </DialogContent>
      </Dialog>
    </Box>
  );
};

export default Cart; 