import React, { useEffect, useState } from 'react';
import api from '../api';
import { Box, Typography, Grid, Card, CardContent, Paper } from '@mui/material';
import { getUser } from '../utils/auth';

const Orders = () => {
  const [orders, setOrders] = useState([]);
  const [revenue, setRevenue] = useState(0);
  const user = getUser();

  useEffect(() => {
    const fetchOrders = async () => {
      if (user.role === 'buyer') {
        const res = await api.get('/orders/buyer');
        setOrders(res.data);
      } else {
        const res = await api.get('/orders/seller');
        setOrders(res.data);
        // Calculate total revenue for seller
        let total = 0;
        res.data.forEach(order => {
          order.products.forEach(item => {
            if (
              item.product &&
              item.product.seller &&
              String(item.product.seller._id || item.product.seller) === String(user.id)
            ) {
              total += item.product.price * item.quantity;
            }
          });
        });
        setRevenue(total);
      }
    };
    fetchOrders();
  }, [user.role, user.id]);

  return (
    <Box p={3}>
      <Typography variant="h4" mb={2}>Orders</Typography>
      {user.role === 'seller' && (
        <Paper elevation={2} sx={{ p: 2, mb: 3, maxWidth: 400 }}>
          <Typography variant="h6" color="primary">Total Revenue</Typography>
          <Typography variant="h5" fontWeight={700}>${revenue}</Typography>
        </Paper>
      )}
      <Grid container spacing={2}>
        {orders.length === 0 && (
          <Typography sx={{ ml: 2, mt: 2 }}>No sales yet.</Typography>
        )}
        {orders.map(order => (
          <Grid item xs={12} md={6} key={order._id}>
            <Card>
              <CardContent>
                <Typography variant="h6">Order #{order._id}</Typography>
                <Typography>Status: {order.status}</Typography>
                <Typography>Total: ${order.total}</Typography>
                <Typography>Products:</Typography>
                <ul>
                  {order.products.map((item, i) =>
                    user.role === 'seller' &&
                    item.product &&
                    item.product.seller &&
                    String(item.product.seller._id || item.product.seller) === String(user.id) ? (
                      <li key={i}>
                        {item.product.title} — Qty: {item.quantity} — Price: ${item.product.price} — Subtotal: ${item.product.price * item.quantity}
                      </li>
                    ) : user.role === 'buyer' ? (
                      <li key={i}>{item.product?.title} x {item.quantity}</li>
                    ) : null
                  )}
                </ul>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
};

export default Orders; 