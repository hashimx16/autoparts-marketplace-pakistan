import React, { useEffect, useState } from 'react';
import api from '../api';
import { Box, Typography, Grid, Card, CardContent, CardActions, Button, TextField } from '@mui/material';
import { useNavigate } from 'react-router-dom';

const BuyerDashboard = () => {
  const [products, setProducts] = useState([]);
  const [search, setSearch] = useState('');
  const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');
  const navigate = useNavigate();

  const fetchProducts = async () => {
    const params = {};
    if (search) params.search = search;
    if (minPrice) params.minPrice = minPrice;
    if (maxPrice) params.maxPrice = maxPrice;
    const res = await api.get('/products', { params });
    setProducts(res.data);
  };

  useEffect(() => { fetchProducts(); }, []);

  const handleAddToCart = (product) => {
    let cart = JSON.parse(localStorage.getItem('cart') || '[]');
    const exists = cart.find(item => item.product._id === product._id);
    if (exists) exists.quantity += 1;
    else cart.push({ product, quantity: 1 });
    localStorage.setItem('cart', JSON.stringify(cart));
    alert('Added to cart!');
  };

  return (
    <Box p={3}>
      <Typography variant="h4" mb={2}>Buyer Dashboard</Typography>
      <Box display="flex" gap={2} mb={2}>
        <TextField label="Search" value={search} onChange={e => setSearch(e.target.value)} />
        <TextField label="Min Price" type="number" value={minPrice} onChange={e => setMinPrice(e.target.value)} />
        <TextField label="Max Price" type="number" value={maxPrice} onChange={e => setMaxPrice(e.target.value)} />
        <Button variant="contained" onClick={fetchProducts}>Filter</Button>
      </Box>
      <Grid container spacing={2}>
        {products.map(product => (
          <Grid item xs={12} sm={6} md={4} key={product._id}>
            <Card>
              <CardContent onClick={() => navigate(`/product/${product._id}`)} style={{ cursor: 'pointer' }}>
                <Typography variant="h6">{product.title}</Typography>
                <Typography>{product.description}</Typography>
                <Typography color="primary">${product.price}</Typography>
                {product.images && product.images.map((img, i) => (
                  <img key={i} src={`http://localhost:5000/uploads/${img}`} alt="" width={80} style={{ marginRight: 8 }} />
                ))}
              </CardContent>
              <CardActions>
                <Button onClick={() => handleAddToCart(product)}>Add to Cart</Button>
              </CardActions>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Box>
  );
};

export default BuyerDashboard; 