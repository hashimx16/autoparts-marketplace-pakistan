import React from 'react';
import { AppBar, Toolbar, Typography, Button, Box } from '@mui/material';
import { Link, useNavigate } from 'react-router-dom';
import { getUser, removeToken, removeUser } from '../../utils/auth';

const Navbar = () => {
  const user = getUser();
  const navigate = useNavigate();

  const handleLogout = () => {
    removeToken();
    removeUser();
    navigate('/login');
  };

  return (
    <AppBar position="static" color="inherit" elevation={1} sx={{ mb: 4 }}>
      <Toolbar>
        <Typography variant="h6" sx={{ flexGrow: 1, color: 'primary.main', fontWeight: 700 }} component={Link} to={user?.role === 'seller' ? '/seller' : '/buyer'} style={{ textDecoration: 'none' }}>
          Pro Parts
        </Typography>
        {user && user.role === 'seller' && (
          <>
            <Button color="primary" component={Link} to="/seller">Dashboard</Button>
            <Button color="primary" component={Link} to="/orders">Orders</Button>
            <Button color="primary" component={Link} to="/profile">Profile</Button>
          </>
        )}
        {user && user.role === 'buyer' && (
          <>
            <Button color="primary" component={Link} to="/buyer">Home</Button>
            <Button color="primary" component={Link} to="/cart">Cart</Button>
            <Button color="primary" component={Link} to="/orders">Orders</Button>
            <Button color="primary" component={Link} to="/profile">Profile</Button>
          </>
        )}
        {user && (
          <Button color="primary" onClick={handleLogout}>Logout</Button>
        )}
      </Toolbar>
    </AppBar>
  );
};

export default Navbar; 